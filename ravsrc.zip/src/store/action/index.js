import { getDashboardDataAction } from "./dashboardAction";

export{
    getDashboardDataAction,

};