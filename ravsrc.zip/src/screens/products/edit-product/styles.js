import styled from 'styled-components';

export const EditWrapper = styled.ScrollView`
  padding: 10px;
  background-color: #fff;
`;
