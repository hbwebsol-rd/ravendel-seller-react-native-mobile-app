import styled from 'styled-components';

export const SettingWrapper = styled.View`
  padding: 10px;
`;
