import styled from 'styled-components';

export const AllCustomerWrapper = styled.ScrollView`
  padding: 10px;
`;
